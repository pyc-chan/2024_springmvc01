package com.ict.project.searchlist.vo;

public class TreeVO {
	private String t_idx, t_ce_na, t_num, t_sdat, t_ty, t_bna, t_tty, t_age, t_ad, t_lat, t_lon, t_dat;

	public String getT_idx() {
		return t_idx;
	}

	public void setT_idx(String t_idx) {
		this.t_idx = t_idx;
	}

	public String getT_ce_na() {
		return t_ce_na;
	}

	public void setT_ce_na(String t_ce_na) {
		this.t_ce_na = t_ce_na;
	}

	public String getT_num() {
		return t_num;
	}

	public void setT_num(String t_num) {
		this.t_num = t_num;
	}

	public String getT_sdat() {
		return t_sdat;
	}

	public void setT_sdat(String t_sdat) {
		this.t_sdat = t_sdat;
	}

	public String getT_ty() {
		return t_ty;
	}

	public void setT_ty(String t_ty) {
		this.t_ty = t_ty;
	}

	public String getT_bna() {
		return t_bna;
	}

	public void setT_bna(String t_bna) {
		this.t_bna = t_bna;
	}

	public String getT_tty() {
		return t_tty;
	}

	public void setT_tty(String t_tty) {
		this.t_tty = t_tty;
	}

	public String getT_age() {
		return t_age;
	}

	public void setT_age(String t_age) {
		this.t_age = t_age;
	}

	public String getT_ad() {
		return t_ad;
	}

	public void setT_ad(String t_ad) {
		this.t_ad = t_ad;
	}

	public String getT_lat() {
		return t_lat;
	}

	public void setT_lat(String t_lat) {
		this.t_lat = t_lat;
	}

	public String getT_lon() {
		return t_lon;
	}

	public void setT_lon(String t_lon) {
		this.t_lon = t_lon;
	}

	public String getT_dat() {
		return t_dat;
	}

	public void setT_dat(String t_dat) {
		this.t_dat = t_dat;
	}
}
